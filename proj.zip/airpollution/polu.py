import serial
import pandas as pd
import matplotlib.pyplot as plt
q=0
a=0
y=[]
w=[]

ser=serial.Serial('COM9',baudrate=9600,timeout=1)
for i in range(20):
    b=ser.readline().decode('utf-8')
    print('gathering temperature data')
    y.append(b)
        
c=[]
for i in range(1,20):
    a=y[i]
    a=int(a[:3])
    c.append(a)
    w.append(q)
    q=q+1

df=pd.DataFrame({
    'index':w,
    'pollution' : c
    })
df.to_csv('s.csv')

df=pd.read_csv('s.csv')
print(df.head())

df.plot(x='index',y='pollution')
plt.show()
    
    
