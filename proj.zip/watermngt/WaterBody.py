import pandas as pd
import csv


def readFromCSV(filename):
    f = open(filename,"r+")
    reader = csv.reader(f)
    return reader

def checkLimit(limit,consumption,result,capacity,names):
    j=0
    checkSum = []
    for j in range(len(limit)):
        Sum=0
        for t in result[j]:
            Sum+=t
        checkSum+=[Sum]
    i=0
    for i in range(len(limit)):
        if(consumption[i]>=limit[i]):
            if(checkSum[i] == max(checkSum)):
                temp = 0
                t=0
                for t in range(len(checkSum)):
                    if(checkSum[t]<max(checkSum) and checkSum[t]>=temp):
                        temp = checkSum[t]
                print("Shifted to another Supply!")
                break
            else:
                temp = 0
                t=0
                for t in range(len(checkSum)):
                    if(checkSum[t]<max(checkSum)):
                        temp = checkSum[t]
                print("Shifted to another Supply!")
                break
        

def Main():
    nxt = readFromCSV("names.csv")
    names = list(nxt)
    #print(names)

    
    nxt = readFromCSV("result.csv")
    result = []

    for each in nxt:
        temp=[]
        for x in each:
            if(x=='0'):
                temp+=[0]
            else:
                temp+=[1]
        result += [temp]

    #print(result)
    
    
    
    data = readFromCSV("limit.csv")
    nxt = list(data)
    limit = []

    i=0
    for i in range(len(nxt)):
        limit += nxt[i]
    
    i=0
    for i in range(len(limit)):
        limit[i]=int(limit[i])

    #print(limit)
    

    
    data=[]
    nxt = []
    data = readFromCSV("consumption.csv")
    nxt = list(data)
    consumption = []

    i=0
    for i in range(len(nxt)):
        consumption += nxt[i]
    
    i=0
    for i in range(len(consumption)):
        consumption[i]=int(consumption[i])

    #print(consumption)


    
    data=[]
    nxt = []
    data = readFromCSV("capacity.csv")
    nxt=list(data)
    capacity = []

    i=0
    for i in range(len(nxt)):
        capacity += nxt[i]

    i=0
    for i in range(len(capacity)):
        capacity[i]=int(capacity[i])

    #print(capacity)
    checkLimit(limit,consumption,result,capacity,names)
    

Main()
